/// @ref core
/// @file glm/exponential.hpp

#pragma once

#include "detail/func_exponential.hpp"
